export const globalStyles = {
  body: {
    backgroundColor: '#D7E1E1',
    color: '#41424b',
    letterSpacing: 0,
  },
  '.report-style-class': {
    height: '100%',
  },
  iframe: {
    border: 'none',
    borderRadius: '0',
  },
}
