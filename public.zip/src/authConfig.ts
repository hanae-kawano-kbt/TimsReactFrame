// ----------------------------------------------------------------------------
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
// ----------------------------------------------------------------------------

/* eslint-disable @typescript-eslint/no-inferrable-types */

// Scope of AAD app. Use the below configuration to use all the permissions provided in the AAD app through Azure portal.
// Refer https://aka.ms/PowerBIPermissions for complete list of Power BI scopes
export const scopes: string[] = [
  'https://analysis.windows.net/powerbi/api/Report.Read.All',
]

// Client Id (Application Id) of the AAD app.
export const clientId: string = 'c70946ea-b41c-4d42-b6eb-b2ca6fb00fe1'

// Id of the workspace where the report is hosted
export const workspaceId: string = '433ec6d7-c29b-476c-9166-be07017cc48d'

// Id of the report to be embedded
export const reportId: string = 'a4edd627-81a9-4ab1-9d3e-3c0b6cf9e479'
