import { Box, Paper, SvgIcon, Theme, Collapse } from '@mui/material'
import { FC, useEffect, useState, useRef, useMemo } from 'react'
import { MenuBar } from './components/Menu'
import { Header } from './components/Header'
import { Menu as MuiMenu, MenuItem } from '@mui/material'
import { UserAgentApplication, AuthError, AuthResponse } from 'msal'
import { clientId, scopes } from './authConfig'
import { PowerBIEmbed } from 'powerbi-client-react'
import { models, Report, service, Embed } from 'powerbi-client'
import 'powerbi-report-authoring'
import {
  menus,
  Detail,
  Under,
  OVERALL_REPORT_NAME,
  TOP_REPORT_NAME,
} from './menuConfig'
import { ReactComponent as arrowLeftIcon } from './assets/icons/arrow_left.svg'
// DatePickerインポート
import { YearPickerCalendar } from './components/YearPickerCalendar'
import { MonthPickerCalendar } from './components/MonthPickerCalendar'
import { WeekPickerCalendar } from './components/WeekPickerCalendar'
import { DayPickerCalendar } from './components/DayPickerCalendar'
import { format, startOfWeek, endOfWeek } from 'date-fns'

const styles = {
  root: {
    width: '100%',
  },
  collapseRoot: {
    zIndex: 1000,
    position: 'absolute',
    boxShadow: '0px 3px 6px #2C28281C',
  },
  contentContainer: {
    height: 'calc(100vh - 13px)',
    windth: '100vw',
    overflow: 'hidden',
    flexGrow: '1',
    padding: '13px 26px 0 30px',
    display: 'flex',
    flexDirection: 'column',
    color: (theme: Theme) => theme.colors.white,
    background: (theme: Theme) =>
      `linear-gradient(180deg, ${theme.colors.mainGreen} 137px, transparent 0%)`,
  },
  btnList: {
    position: 'relative',
    height: '70px',
  },
  topBtn: {
    padding: '13px 0',
  },
  btnMenu: {
    display: 'flex',
    position: 'absolute',
    left: '60px',
    padding: '13px 0',
  },
  powerbiContainer: {
    flexGrow: '1',
    marginTop: '13px',
    borderRadius: '0',
    background: 'none',
    padding: '0',
    boxShadow: 'none',
  },
  backBtn: {
    height: 44,
    width: 44,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    cursor: 'pointer',
    border: (theme: Theme) => `1px solid ${theme.colors.line}`,
    borderRadius: 2,
    boxShadow: '0px 3px 6px #1717172d',
    '&:hover': {
      color: (theme: Theme) => theme.colors.mainGreen,
      backgroundColor: (theme: Theme) => theme.colors.white,
    },
  },
  btn: {
    height: 44,
    minWidth: 80,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#28b8b9',
    cursor: 'pointer',
    border: (theme: Theme) => `1px solid ${theme.colors.line}`,
    '&:nth-of-type(1)': {
      borderRight: 'none',
      borderTopLeftRadius: 8,
      borderBottomLeftRadius: 8,
    },
    '&:last-child': {
      borderLeft: 'none',
      borderTopRightRadius: 8,
      borderBottomRightRadius: 8,
    },
    '&:hover': {
      color: (theme: Theme) => theme.colors.mainGreen,
      backgroundColor: (theme: Theme) => theme.colors.white,
    },
  },
  clickedBtn: {
    color: (theme: Theme) => theme.colors.mainGreen,
    backgroundColor: (theme: Theme) => theme.colors.white,
  },
  bookmarksContainer: {
    position: 'relative',
    boxShadow: '0px 3px 6px #1717172d',
    borderRadius: '8px',
  },
  subMenu: {
    transform: 'translate(0, -21.5px)',
    '& .MuiList-root': {
      py: '11px',
    },
    '& .MuiMenuItem-root': {
      padding: '4px 14px',
      color: (theme: Theme) => theme.colors.gray,
    },
  },
  subMenuPaper: {
    background: '#d8efef',
    overflow: 'visible',
    filter: 'drop-shadow(0px 3px 6px #2c28281c)',
    borderRadius: 0,
    mt: 1.5,
    '&:before': {
      content: '""',
      display: 'block',
      position: 'absolute',
      top: 0,
      left: 20,
      width: 20,
      height: 20,
      bgcolor: '#d8efef',
      transform: 'translate(-50%, -50%) rotate(45deg)',
      zIndex: 0,
    },
  },
}

export type CurrentMenu = {
  mainTitle: string
  subMenuTitle: string | undefined
  subMenuEmbedUrl: string | undefined
  subMenuDateSlicerType?: string | undefined //subMenu日付スライサー種別
  detailTitle: string | undefined
  detailEmbedUrl: string | undefined
  detailsDateSlicerType?: string | undefined //details日付スライサー種別
  underMenu: Under[] | undefined
  underMenuTitle: string | undefined
  underMenuEmbedUrl: string | undefined
  underMenuDateSlicerType?: string | undefined //underMenu日付スライサー種別
  noMenuFlag: boolean | undefined
}

// POST先テーブル/カラム名
export const FILTER_DATE = 'FILTER_DATE' //テーブル名
export const YEAR_STRING = 'YEAR_STRING' //カラム名(対象：'年')
export const MONTH_STRING = 'MONTH_STRING' //カラム名(対象：'月')
export const START_OF_WEEK = 'START_OF_WEEK' //カラム名(対象：'週')
export const DATE_STRING = 'DATE_STRING' //カラム名(対象：'日')

export const Tims: FC = () => {
  // システム日付
  const today = new Date()
  // 現在表示しているPowerBIの情報
  // 初期で工場全体の情報を設定する
  const [currentMenu, setCurrentMenu] = useState<CurrentMenu>({
    // 初期でmainTitleが「工場全体」
    mainTitle: menus[0].title,
    // 初期でsubMenuTitleが「トップ」
    // ※工場全体の場合に、「トップ」を定義しているが、サイドメニューに表示する必要ない、「工場全体」のメニューを押下すると、すぐ「工場全体」のPowerBIを表示する）
    // ※「工場全体」のメニュー以外はメニューをクリックするとサブメニューが現れる
    subMenuTitle: menus[0].subMenu[0].title,
    subMenuEmbedUrl: menus[0].subMenu[0].embedUrl,
    subMenuDateSlicerType: menus[0].subMenu[0].dateSlicerType, //subMenu日付スライサー種別
    // 「S」「Q」「Mc」などのヘッダーのメニュー
    //　初期でなのも設定しない
    detailTitle: undefined,
    detailEmbedUrl: undefined,
    underMenu: undefined,
    underMenuTitle: undefined,
    underMenuEmbedUrl: undefined,
    detailsDateSlicerType: undefined, //details日付スライサー種別
    underMenuDateSlicerType: undefined, //underMenu日付スライサー種別
    // 課の下層メニューがあるかないか
    noMenuFlag: menus[0].noMenuFlag ? menus[0].noMenuFlag : false,
  })
  // ブックマークのリスト
  const [bookmarks, setBookmarks] = useState<
    models.IReportBookmark[] | undefined
  >(undefined)

  // Filterのパラメータ
  // 年
  const [yearPickerDate, setYearPickerDate] = useState<Date>(today)
  // 年月
  const [monthPickerDate, setMonthPickerDate] = useState<Date>(today)
  // 週
  const [weekPickerDate, setWeekPickerDate] = useState<Date>(today)
  // 日付け
  const [dayPickerDate, setDayPickerDate] = useState<Date>(today)

  // 選択しているブックマーク
  const [currentBookmark, setCurrentBookmark] = useState<
    models.IReportBookmark | undefined
  >(undefined)
  // サイドメニューが展開しているかステート
  const [isOpenMenu, setIsOpenMenu] = useState<boolean>(false)
  // レポートDOMのrefを保管するref
  const reportRef = useRef<Report | undefined>(undefined)
  // トークン
  // アイエンター社内に開発する時、PowerBIのサイトからトークンを取って開発する（1時間ごとに再取得必要）
  // クボタ様を渡す時に、「undefined」で設定
  const accessToken = useRef<string | undefined>(
    'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6Ii1LSTNROW5OUjdiUm9meG1lWm9YcWJIWkdldyIsImtpZCI6Ii1LSTNROW5OUjdiUm9meG1lWm9YcWJIWkdldyJ9.eyJhdWQiOiJodHRwczovL2FuYWx5c2lzLndpbmRvd3MubmV0L3Bvd2VyYmkvYXBpIiwiaXNzIjoiaHR0cHM6Ly9zdHMud2luZG93cy5uZXQvMzc1NmYxOTYtZDdkYi00NTFiLWIyYTktOWUxYTAxODU1ZmUxLyIsImlhdCI6MTY3MTUyMTM1NywibmJmIjoxNjcxNTIxMzU3LCJleHAiOjE2NzE1MjUzNzAsImFjY3QiOjAsImFjciI6IjEiLCJhaW8iOiJBVlFBcS84VEFBQUFFQWkrdGF2dm1wZjlGTzhWM1dSOU41WHkwcWFNdnYxUmczRnpmSU9vNU11MXlNN2ZCUXNGTm1rVm9IREFUTnNzWG41dlg0TVI1V2gyMEpaZG1XMCtDazFUNTllMkRjOXpLaitvQnRVK3hCQT0iLCJhbXIiOlsicHdkIiwibWZhIl0sImFwcGlkIjoiODcxYzAxMGYtNWU2MS00ZmIxLTgzYWMtOTg2MTBhN2U5MTEwIiwiYXBwaWRhY3IiOiIyIiwiZmFtaWx5X25hbWUiOiLmsrPph44iLCJnaXZlbl9uYW1lIjoi6Iux5oG1IiwiaXBhZGRyIjoiMjE3LjE3OC4yMy4xNCIsIm5hbWUiOiLmsrPph44g6Iux5oG1Iiwib2lkIjoiMTkxMzU0YzMtZWUwYy00YmY0LWEwMzctYWY2YzJhYTQ5YTFmIiwib25wcmVtX3NpZCI6IlMtMS01LTIxLTMwNDM0NTk2NTctMzQ2ODQ2MjQ1OC0yMDI1MjAzNjg1LTE5MzI1IiwicHVpZCI6IjEwMDMyMDAxMURDMzVFMDMiLCJyaCI6IjAuQVQwQWx2RldOOXZYRzBXeXFaNGFBWVZmNFFrQUFBQUFBQUFBd0FBQUFBQUFBQUE5QUlRLiIsInNjcCI6InVzZXJfaW1wZXJzb25hdGlvbiIsInNpZ25pbl9zdGF0ZSI6WyJrbXNpIl0sInN1YiI6Ikpjbm91SWJGcE93RmVyRFAtQ3FrV0VHa184dm1icDVJaGNfSGdQZEI3c00iLCJ0aWQiOiIzNzU2ZjE5Ni1kN2RiLTQ1MWItYjJhOS05ZTFhMDE4NTVmZTEiLCJ1bmlxdWVfbmFtZSI6Imgta2F3YW5vQGktZW50ZXIuY28uanAiLCJ1cG4iOiJoLWthd2Fub0BpLWVudGVyLmNvLmpwIiwidXRpIjoiY0ZTQjNnaDQxVW1XeXd4dlBXVEhBQSIsInZlciI6IjEuMCIsIndpZHMiOlsiYjc5ZmJmNGQtM2VmOS00Njg5LTgxNDMtNzZiMTk0ZTg1NTA5Il19.KFH1xYJLn9mLKIaM0SxfWtxUzfOGlfCo7I53AXOopDzB7763KLnZ3CoqGi8NNSC4k7pMZBw3LI4RxkCaIAOp4f8gvQTU32tqbOi5cilUAHhoBuymWb4_gVpMRkVC344_exQEJjXHjkDDGP9VVqBvrQH-qLp15xAcC7wZf2oOuLwgIaLfeXF6hZ7k6HstiQ7NfuawhewwnbKV03CRn8F2fUPpzEDVZCa6Xe3oWwzuYyT6Pmdve8Q2nYZmGNb_g9O3y0oDGGPatARfkv2TPeDIUxGJUVNv59j-ofPrQ8TpEExk-S4dHd2MB3xKbz0lIkqMwxj2wrFNYkhszX18r_opVg'
  )
  // 最下層メニューの開閉
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null)
  const open = Boolean(anchorEl)
  const handleClick = (
    event: React.MouseEvent<HTMLElement>,
    mainTitle: string
  ) => {
    setAnchorEl(event.currentTarget)
  }
  // 最下層メニューの開閉
  const handleClose = () => {
    setAnchorEl(null)
  }

  // 「工場全体」のPowerBIを表示しているか変数
  const isMainPage = useMemo(
    () =>
      currentMenu.mainTitle === OVERALL_REPORT_NAME &&
      currentMenu.subMenuTitle === TOP_REPORT_NAME &&
      currentMenu.detailTitle === undefined,
    [currentMenu]
  )

  // PowerBIを表示するのに設定の値
  const [reportConfig, setReportConfig] =
    useState<models.IReportEmbedConfiguration>({
      type: 'report',
      // 表示するembedUrl
      embedUrl: undefined,
      // トークン
      accessToken: undefined,
      // トークンのタイプ
      //　アイエンター内に実装する時に、「Aad」にする
      // クボタ様を渡す時に、「Embed」で設定
      tokenType: models.TokenType.Aad,
      // tokenType: models.TokenType.Embed,
      settings: {
        panes: {
          filters: {
            // フィルターパネルを表示しないように設定
            expanded: false,
            visible: false,
          },
          pageNavigation: {
            // エクセルみたいに下ページパネルを表示しないように設定
            visible: false,
          },
        },
      },
    })

  const loadedEvent = async () => {
    if (reportRef.current === undefined) return

    try {
      // ブックマークを取得
      const bookmarks = await reportRef.current.bookmarksManager.getBookmarks()
      // 「()」で囲まれるブックマークしか取得しない
      const filteredBookmarks = bookmarks.filter((item) =>
        /^\(.+\)$/.test(item.displayName)
      )
      //　ブックマークのリストをセット
      setBookmarks(filteredBookmarks)
      if (currentBookmark === undefined)
        setCurrentBookmark(filteredBookmarks[0])
      selectedDatePost()
    } catch (error) {
      console.log(error)
    }
  }

  const eventHandlersMap = new Map([
    // PowerBIが取得される時
    ['loaded', async () => {}],
    // PowerBIが表示される時
    ['rendered', async () => {}],
    // PowerBIのエラーが発生する時
    [
      'error',
      (event?: service.ICustomEvent<any>) => {
        if (event) {
          console.error(event.detail)
        }
      },
    ],
    // ボタンがクリックされる時
    [
      'buttonClicked',
      (event: any) => {
        // ボタンをクリックした時に、ボタンのtitleを取得できる
        // titleは「トラクタ課/トップ/S」という形に設定されている

        //　titleを取得「トラクタ課/トップ/S」
        const destinationTitle = event.detail.title
        console.log('クリックしたタイトル' + destinationTitle)
        //　titleを分解する["トラクタ課","トップ","S"]
        const destinationTitleExplode = destinationTitle.split('/')

        // 外だしJSONファイルにPowerBIのembedUrlを検索する
        // メインメニューを検索(工場全体やトラクタ課など)
        const menu = menus.find(
          (menu) => menu.title === destinationTitleExplode[0]
        )
        if (menu === undefined) return
        //　メインメニューの中のサブメニューを検索(トップやMARなど)
        const subMenu = menu.subMenu.find(
          (subMenu: any) => subMenu.title === destinationTitleExplode[1]
        )
        if (subMenu === undefined) return
        //　もっと細かくメニューを検索(SやQやMcなど)
        const detail = subMenu.details.find(
          (subMenu: any) => subMenu.title === destinationTitleExplode[2]
        )

        // 表示させるPowerBI情報を設定する
        setCurrentMenu({
          mainTitle: menu.title,
          subMenuTitle: subMenu.title,
          subMenuEmbedUrl: subMenu.embedUrl,
          subMenuDateSlicerType: subMenu.dateSlicerType, //subMenu日付スライサー種別
          detailTitle: detail ? detail.title : undefined,
          detailEmbedUrl: detail ? detail.embedUrl : undefined,
          detailsDateSlicerType: detail ? detail.dateSlicerType : undefined, //details日付スライサー種別
          underMenu: undefined,
          underMenuTitle: undefined,
          underMenuEmbedUrl: undefined,
          underMenuDateSlicerType: undefined, //underMenu日付スライサー種別
          noMenuFlag: subMenu.noMenuFlag ? subMenu.noMenuFlag : false,
        })
      },
    ],
  ])

  // トークンを取得するため認証を行う関数(検証できないので、サンプルのまま実装)
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const authenticate = () => {
    console.log('Auth')
    const msalConfig = {
      auth: {
        clientId: clientId,
      },
    }

    const loginRequest = {
      scopes: scopes,
    }

    const msalInstance: UserAgentApplication = new UserAgentApplication(
      msalConfig
    )

    const successCallback = (response: AuthResponse) => {
      console.log('success', response)
      if (response.tokenType === 'id_token') {
        authenticate()
      } else if (response.tokenType === 'access_token') {
        accessToken.current = response.accessToken

        // Refresh User Permissions
        tryRefreshUserPermissions()
        // getembedUrl(config.reportId)
        setReportConfig({
          ...reportConfig,
          accessToken: response.accessToken,
          embedUrl: currentMenu?.subMenuEmbedUrl,
        })
      } else {
        console.log('Token type is: ' + response.tokenType)
      }
    }

    const failCallBack = (error: AuthError) => {
      console.log('Authentication was fail', error)
    }

    msalInstance.handleRedirectCallback(successCallback, failCallBack)

    // check if there is a cached user
    if (msalInstance.getAccount()) {
      // get access token silently from cached id-token
      msalInstance
        .acquireTokenSilent(loginRequest)
        .then((response: AuthResponse) => {
          // get access token from response: response.accessToken
          accessToken.current = response.accessToken
          // getembedUrl(config.reportId)
          setReportConfig({
            ...reportConfig,
            accessToken: response.accessToken,
            embedUrl: currentMenu?.subMenuEmbedUrl,
          })
        })
        .catch((err: AuthError) => {
          // refresh access token silently from cached id-token
          // makes the call to handleredirectcallback
          if (err.name === 'InteractionRequiredAuthError') {
            msalInstance.acquireTokenRedirect(loginRequest)
          } else {
            console.log('Authentication was fail', err)
          }
        })
    } else {
      // user is not logged in or cached, you will need to log them in to acquire a token
      msalInstance.loginRedirect(loginRequest)
    }
  }

  // 再認証を行う関数(検証できないので、サンプルのまま実装)
  const tryRefreshUserPermissions = () => {
    fetch('https://api.powerbi.com/v1.0/myorg/RefreshUserPermissions', {
      headers: {
        Authorization: 'Bearer ' + accessToken.current,
      },
      method: 'POST',
    })
      .then(function (response) {
        if (response.ok) {
          console.log('User permissions refreshed successfully.')
        } else {
          // Too many requests in one hour will cause the API to fail
          if (response.status === 429) {
            console.error(
              'Permissions refresh will be available in up to an hour.'
            )
          } else {
            console.error(response)
          }
        }
      })
      .catch(function (error) {
        console.error('Failure in making API call.' + error)
      })
  }

  useEffect(() => {
    console.log('初期表示')
    // クボタ様を渡す時に、authenticate()を行うため、コメントを戻す
    // authenticate()
    reportRef.current?.off('loaded')
    reportRef.current?.on('loaded', loadedEvent)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    if (accessToken.current === undefined) return
    // PowerBIを切り替える時に、ブックマークをクリアする
    setCurrentBookmark(undefined)
    //　切り替える先のPowerBIを判断
    //　currentMenuにdetailメニューの情報がある場合にdetail(S,Q,Mcなど)のPowerBIを表示するわけ
    //　currentMenuにdetailメニューの情報がない場合にsuvMenuのPowerBIを表示するわけ
    let embedUrl = undefined
    if (currentMenu.underMenuEmbedUrl) {
      embedUrl = currentMenu.underMenuEmbedUrl
    } else if (currentMenu.detailEmbedUrl) {
      embedUrl = currentMenu.detailEmbedUrl
    } else {
      embedUrl = currentMenu.subMenuEmbedUrl
    }

    //　レポートの設定を設定する
    setReportConfig({
      ...reportConfig,
      accessToken: accessToken.current,
      embedUrl: embedUrl,
    })
    reportRef.current?.off('loaded')
    reportRef.current?.on('loaded', loadedEvent)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentMenu])

  // ブックマークを選択時
  const HandleChangeBookmark = async (item: models.IReportBookmark) => {
    if (reportRef.current === undefined) return
    try {
      await reportRef.current.bookmarksManager.apply(item.name)
      setCurrentBookmark(item)
    } catch (errors) {
      console.log(errors)
    }
  }

  // 「S」「Q」「C」などを選択時
  const HandleChangeDetail = (detail: Detail) => {
    // console.log('「S」「Q」「C」などを選択時')
    if (detail.underMenu) {
      setCurrentMenu({
        ...currentMenu,
        detailTitle: detail.title,
        //最下層をセット
        underMenu: detail.underMenu,
      })
    } else if (detail.anotherTabFlag) {
      window.open(detail.embedUrl, '_blank')
    } else {
      setCurrentMenu({
        ...currentMenu,
        detailTitle: detail.title,
        detailEmbedUrl: detail.embedUrl,
        detailsDateSlicerType: detail.dateSlicerType, //details日付スライサー種別追加
        underMenu: undefined,
        underMenuTitle: undefined,
        underMenuEmbedUrl: undefined,
        underMenuDateSlicerType: undefined, //underMenu日付スライサー種別追加
      })
    }
  }

  // 最下層メニューを取得
  const HandleChangeUnder = (under: Under) => {
    setCurrentMenu({
      ...currentMenu,
      //最下層の値をセット
      underMenuTitle: under.title,
      underMenuEmbedUrl: under.embedUrl,
      underMenuDateSlicerType: under.dateSlicerType, //underMenu日付スライサー種別
    })
  }

  // バックボタン押下時
  const handleBack = () => {
    // 最下層メニューのPowerBIを表示している間にバックボタンを押下
    if (
      currentMenu.underMenuTitle !== undefined &&
      currentMenu.underMenuEmbedUrl !== undefined
    ) {
      // detailのPowerBIの情報を削除する（underとdetailの情報を削除し、subMenuのPowerBiを表示）
      setCurrentMenu({
        ...currentMenu,
        detailTitle: undefined,
        detailEmbedUrl: undefined,
        detailsDateSlicerType: undefined, //detail日付スライサー種別削除
        underMenu: undefined,
        underMenuTitle: undefined,
        underMenuEmbedUrl: undefined,
        underMenuDateSlicerType: undefined, //underMenu日付スライサー種別削除
      })
      return
    }

    // detailのPowerBIを表示している間、バックボタンを押下
    if (
      currentMenu.detailTitle !== undefined &&
      currentMenu.detailEmbedUrl !== undefined
    ) {
      // detailのPowerBIの情報を削除する（detailの情報がないと勝手に、subMenuのPowerBiを表示）
      setCurrentMenu({
        ...currentMenu,
        detailTitle: undefined,
        detailEmbedUrl: undefined,
        detailsDateSlicerType: undefined, //detail日付スライサー種別削除
      })
      return
    }

    // subMenu(トップの場合)のPowerBIを表示している間に、バックボタンを押下
    if (
      currentMenu.mainTitle !== OVERALL_REPORT_NAME &&
      currentMenu.subMenuTitle === TOP_REPORT_NAME
    ) {
      //　工場全体に画面遷移するため、工場全体のPowerBIの情報を検索
      const overallReport = menus
        .find((menu) => menu.title === OVERALL_REPORT_NAME)
        ?.subMenu.find((subMenu) => subMenu.title === TOP_REPORT_NAME)
      setCurrentMenu({
        mainTitle: OVERALL_REPORT_NAME,
        subMenuTitle: overallReport?.title,
        subMenuEmbedUrl: overallReport?.embedUrl,
        subMenuDateSlicerType: overallReport?.dateSlicerType, //subMenu日付スライサー種別
        detailTitle: undefined,
        detailEmbedUrl: undefined,
        detailsDateSlicerType: undefined, //details日付スライサー種別
        underMenu: undefined,
        underMenuTitle: undefined,
        underMenuEmbedUrl: undefined,
        underMenuDateSlicerType: undefined, //underMenu日付スライサー種別
        noMenuFlag: overallReport?.noMenuFlag
          ? overallReport?.noMenuFlag
          : false,
      })
      return
    }

    // 検査課などをスキップ
    if (
      currentMenu.mainTitle !== OVERALL_REPORT_NAME &&
      !currentMenu.noMenuFlag //下の階層のembedUrlが空かどうかに修正
    ) {
      //　工場全体に画面遷移するため、工場全体のPowerBIの情報を検索
      const overallReport = menus
        .find((menu) => menu.title === OVERALL_REPORT_NAME)
        ?.subMenu.find((subMenu) => subMenu.title === TOP_REPORT_NAME)
      setCurrentMenu({
        mainTitle: OVERALL_REPORT_NAME,
        subMenuTitle: overallReport?.title,
        subMenuEmbedUrl: overallReport?.embedUrl,
        subMenuDateSlicerType: overallReport?.dateSlicerType, //subMenu日付スライサー種別
        detailTitle: undefined,
        detailEmbedUrl: undefined,
        detailsDateSlicerType: undefined, //details日付スライサー種別
        underMenu: undefined,
        underMenuTitle: undefined,
        underMenuEmbedUrl: undefined,
        underMenuDateSlicerType: undefined, //underMenu日付スライサー種別
        noMenuFlag: overallReport?.noMenuFlag
          ? overallReport?.noMenuFlag
          : false,
      })
      return
    }

    // subMenu(トップ以外)のPowerBIを表示している間に、バックボタンを押下
    if (
      currentMenu.mainTitle !== OVERALL_REPORT_NAME &&
      currentMenu.subMenuTitle !== TOP_REPORT_NAME
    ) {
      //　課のトップに画面遷移するため、課のトップのPowerBIの情報を検索
      //console.log('subMenu(トップ以外)のPowerBIを表示している間に、バックボタンを押下')
      const topReport = menus
        .find((menu) => menu.title === currentMenu.mainTitle)
        ?.subMenu.find((subMenu) => subMenu.title === TOP_REPORT_NAME)
      setCurrentMenu({
        mainTitle: currentMenu.mainTitle,
        subMenuTitle: topReport?.title,
        subMenuEmbedUrl: topReport?.embedUrl,
        subMenuDateSlicerType: topReport?.dateSlicerType, //subMenu日付スライサー種別
        detailTitle: undefined,
        detailEmbedUrl: undefined,
        detailsDateSlicerType: undefined, //details日付スライサー種別
        underMenu: undefined,
        underMenuTitle: undefined,
        underMenuEmbedUrl: undefined,
        underMenuDateSlicerType: undefined, //underMenu日付スライサー種別
        noMenuFlag: topReport?.noMenuFlag ? topReport?.noMenuFlag : false,
      })
      return
    }
  }

  // Datepicker再選択時レンダリング
  // 年
  useEffect(() => {
    // 年フィルタを設定する
    yearDateFilter(yearPickerDate)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [yearPickerDate])
  // 年月
  useEffect(() => {
    // 月フィルタを設定する
    monthDateFilter(monthPickerDate)
  }, [monthPickerDate])
  // // 週
  useEffect(() => {
    // 週フィルタを設定する
    weekDateFilter(weekPickerDate)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [weekPickerDate])
  // // 日付け
  useEffect(() => {
    // 日付けフィルタを設定する
    dayDateFilter(dayPickerDate)
  }, [dayPickerDate])

  // 各コンポーネントPOST
  // 年
  const yearDateFilter = async (yearPickerDate: Date) => {
    console.log('年フィルタ実行:' + format(yearPickerDate, 'yyyy'))

    const filterYear = {
      $schema: 'http://powerbi.com/product/schema#basic',
      target: {
        table: FILTER_DATE,
        column: YEAR_STRING,
      },
      operator: 'In',
      values: [format(yearPickerDate, 'yyyy')],
      filterType: models.FilterType.Basic,
      requireSingleSelection: true,
    }
    setTimeout(async () => {
      const pages = await reportRef.current!.getPages()
      const activePage = pages?.filter(function (page) {
        return page.isActive
      })[0]

      await activePage.updateFilters(models.FiltersOperations.Replace, [
        filterYear,
      ])
    }, 500)
  }
  // 年月
  const monthDateFilter = async (monthPickerDate: Date) => {
    console.log('月フィルタ実行:' + format(monthPickerDate, 'yyyy/MM'))

    const filterMonth = {
      $schema: 'http://powerbi.com/product/schema#basic',
      target: {
        table: FILTER_DATE,
        column: MONTH_STRING,
      },
      operator: 'In',
      values: [format(monthPickerDate, 'yyyy/MM')],
      filterType: models.FilterType.Basic,
      requireSingleSelection: true,
    }
    setTimeout(async () => {
      const pages = await reportRef.current!.getPages()
      const activePage = pages?.filter(function (page) {
        return page.isActive
      })[0]
      await activePage.updateFilters(models.FiltersOperations.Replace, [
        filterMonth,
      ])
    }, 500)
  }
  // 週
  const weekDateFilter = async (weekPickerDate: Date) => {
    console.log('週フィルタ実行:' + getDisplayDate(weekPickerDate))

    const filterWeek = {
      $schema: 'http://powerbi.com/product/schema#basic',
      target: {
        table: FILTER_DATE,
        column: START_OF_WEEK,
      },
      operator: 'In',
      values: [format(startOfWeek(weekPickerDate), 'yyyy/MM/dd')], //週の始まり(日曜)日付け
      filterType: models.FilterType.Basic,
      requireSingleSelection: true,
    }
    setTimeout(async () => {
      const pages = await reportRef.current!.getPages()
      const activePage = pages?.filter(function (page) {
        return page.isActive
      })[0]
      await activePage.updateFilters(models.FiltersOperations.Replace, [
        filterWeek,
      ])
    }, 500)
  }
  // 日付け
  const dayDateFilter = async (dayPickerDate: Date) => {
    console.log('日付けフィルタ実行:' + format(dayPickerDate, 'yyyy/MM/dd'))

    const filterDay = {
      $schema: 'http://powerbi.com/product/schema#basic',
      target: {
        table: FILTER_DATE,
        column: DATE_STRING,
      },
      operator: 'In',
      values: [format(dayPickerDate, 'yyyy/MM/dd')],
      filterType: models.FilterType.Basic,
      requireSingleSelection: true,
    }
    setTimeout(async () => {
      const pages = await reportRef.current!.getPages()
      const activePage = pages?.filter(function (page) {
        return page.isActive
      })[0]
      await activePage.updateFilters(models.FiltersOperations.Replace, [
        filterDay,
      ])
    }, 500)
  }

  // 週モードの表示
  const getDisplayDate = (value: Date | null) => {
    if (value == null) {
      return ''
    } else {
      const start = format(startOfWeek(value), 'yyyy/MM/dd')
      const end = format(endOfWeek(value), 'MM/dd')
      return start + ' ~ ' + end
    }
  }

  // 各DataPickerコンポーネントPOST呼び出し
  const selectedDatePost = () => {
    //年のパターン
    if (menuFilterType === 'year') {
      yearDateFilter(yearPickerDate)
    }
    //月のパターン
    else if (menuFilterType === 'month') {
      monthDateFilter(monthPickerDate)
    }
    //週のパターン
    else if (menuFilterType === 'week') {
      weekDateFilter(weekPickerDate)
    }
    //日付のパターン
    else if (menuFilterType === 'day') {
      dayDateFilter(dayPickerDate)
    }
    //その他('none'含め)
    else {
      return
    }
  }

  // DataPicker切替
  const menuFilterType = useMemo(() => {
    // currentMenuが更新されるとこの処理が走って、menuFilterTypeにreturnが返される
    //最下層選択時
    if (currentMenu.underMenuDateSlicerType !== undefined) {
      // menuFilterTypeにcurrentMenu.underMenuDateSlicerTypeを入れる
      return currentMenu.underMenuDateSlicerType
    }
    //「S」「Q」「C」などを選択時
    else if (currentMenu.detailsDateSlicerType !== undefined) {
      return currentMenu.detailsDateSlicerType
    }
    //サブメニュー選択時
    else if (currentMenu.subMenuDateSlicerType !== undefined) {
      return currentMenu.subMenuDateSlicerType
    } else {
      // どれでもなかったらundefined
      return undefined
    }
    // currentMenuの更新がトリガー
  }, [currentMenu])

  return (
    <Box sx={styles.root} display="flex">
      <Collapse
        in={isOpenMenu}
        orientation="horizontal"
        sx={styles.collapseRoot}
      >
        <MenuBar
          setIsOpenMenu={setIsOpenMenu}
          isOpenMenu={isOpenMenu}
          currentMenu={currentMenu}
          setCurrentMenu={setCurrentMenu}
          reportConfig={reportConfig}
          setReportConfig={setReportConfig}
        />
      </Collapse>
      <Box sx={styles.contentContainer} width="100%">
        <Header
          setIsOpenMenu={setIsOpenMenu}
          isOpenMenu={isOpenMenu}
          currentMenu={currentMenu}
          setCurrentMenu={setCurrentMenu}
        />
        <Box display="flex" sx={styles.btnList} width="100%">
          <Box style={styles.topBtn}>
            {!isMainPage && (
              <Box
                sx={styles.backBtn}
                mr={4}
                display="flex"
                alignItems="center"
                justifyContent="center"
                onClick={handleBack}
              >
                <SvgIcon
                  component={arrowLeftIcon}
                  sx={{ width: 'auto', height: 'auto' }}
                  width="18"
                  height="15.43"
                  viewBox="0 0 18 15.428"
                />
              </Box>
            )}
          </Box>
          <Box py={4} sx={styles.btnMenu} width="100%">
            <Box
              display="flex"
              sx={styles.bookmarksContainer}
              mr={bookmarks && bookmarks.length > 0 ? 4 : 0}
            >
              {bookmarks &&
                bookmarks.map((item) => {
                  if (item === null) return <Box />
                  const display = item.displayName.match(/\(([^)]*)\)/)![1]
                  return (
                    <Box
                      sx={{
                        ...styles.btn,
                        ...(currentBookmark?.displayName === item.displayName
                          ? styles.clickedBtn
                          : {}),
                      }}
                      key={item.displayName}
                      onClick={() => {
                        HandleChangeBookmark(item)
                      }}
                    >
                      {display}
                    </Box>
                  )
                })}
            </Box>
            <Box
              display="flex"
              justifyContent="space-between"
              width="100%"
              alignItems="center"
            >
              <Box display="flex" sx={styles.bookmarksContainer}>
                {menus
                  .find((menu) => menu.title === currentMenu.mainTitle)
                  ?.subMenu.find(
                    (subMenu) => subMenu.title === currentMenu.subMenuTitle
                  )
                  ?.details.map((detial) => {
                    return (
                      <Box
                        sx={{
                          ...styles.btn,
                          ...(currentMenu.detailTitle === detial.title
                            ? styles.clickedBtn
                            : {}),
                          minWidth: 44,
                        }}
                        key={detial.title}
                        onClick={(e) => {
                          HandleChangeDetail(detial)
                          if (detial.underMenu) {
                            handleClick(e, detial.title)
                          }
                        }}
                      >
                        {detial.title}
                      </Box>
                    )
                  })}
                <MuiMenu
                  anchorEl={anchorEl}
                  id="sub-menu"
                  open={open}
                  onClose={handleClose}
                  onClick={handleClose}
                  sx={styles.subMenu}
                  PaperProps={{
                    elevation: 0,
                    sx: styles.subMenuPaper,
                  }}
                  transformOrigin={{ horizontal: 'left', vertical: 'top' }}
                  anchorOrigin={{ horizontal: 0, vertical: 70 }}
                >
                  {menus
                    .find((menu) => menu.title === currentMenu.mainTitle)
                    ?.subMenu.find(
                      (subMenu) => subMenu.title === currentMenu.subMenuTitle
                    )
                    ?.details.find(
                      (detial) => detial.title === currentMenu.detailTitle
                    )
                    ?.underMenu?.map((under) => (
                      <MenuItem
                        key={under.title}
                        onClick={(e) => HandleChangeUnder(under)}
                      >
                        {under.title}
                      </MenuItem>
                    ))}
                </MuiMenu>
              </Box>

              {/* DataPicker */}
              <Box mr="60px">
                {menuFilterType === 'year' && (
                  <YearPickerCalendar
                    yearPickerDate={yearPickerDate}
                    setYearPickerDate={setYearPickerDate}
                  ></YearPickerCalendar>
                )}
                {menuFilterType === 'month' && (
                  <MonthPickerCalendar
                    monthPickerDate={monthPickerDate}
                    setMonthPickerDate={setMonthPickerDate}
                  ></MonthPickerCalendar>
                )}
                {menuFilterType === 'week' && (
                  <WeekPickerCalendar
                    weekPickerDate={weekPickerDate}
                    setWeekPickerDate={setWeekPickerDate}
                  ></WeekPickerCalendar>
                )}
                {menuFilterType === 'day' && (
                  <DayPickerCalendar
                    dayPickerDate={dayPickerDate}
                    setDayPickerDate={setDayPickerDate}
                  ></DayPickerCalendar>
                )}
              </Box>
            </Box>
          </Box>
        </Box>
        <Box component={Paper} p={2} sx={styles.powerbiContainer}>
          <PowerBIEmbed
            embedConfig={reportConfig}
            eventHandlers={eventHandlersMap}
            cssClassName={'report-style-class'}
            getEmbeddedComponent={(embedObject: Embed) => {
              // console.log(
              //   `Embedded object of type "${embedObject.embedtype}" received`,
              //   embedObject
              // )
              reportRef.current = embedObject as Report
            }}
          />
        </Box>
      </Box>
    </Box>
  )
}
